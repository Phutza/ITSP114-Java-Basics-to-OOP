
/**
 * Prints the clients name and balance with a message.
 *
 * @author (31546455)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class Question_2
{
    public static void main(String[]args)
    {
        
        Scanner sc = new Scanner(System.in);
        String name;
        String Client_balance;
        
        
        System.out.print("Please enter your name: ");
        name = sc.nextLine();
        System.out.print("Please enter your balance: ");
        Client_balance = sc.nextLine();
        
        switch(Client_balance.charAt(0))
        {
           
            case '-':
                System.out.println(name + ", your balance is: " + Client_balance + "."+ 
                "\nApologies " +name +", you are not to use this services with a "+ 
                "negative balance");
                break;
            default: 
                System.out.println(name + ", Your balance is R" + Client_balance + ".");
                break;
        }
    }
    
}
