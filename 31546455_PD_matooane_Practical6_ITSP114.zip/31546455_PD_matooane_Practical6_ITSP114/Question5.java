import java.util.Scanner;

/**
 * Write a description of class Q5 here.
 *
 * @author (31546455)
 * @version (a version number or a date)
 */
public class Question5
{
  public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String name1, name2, name3;

        System.out.print("Please enter three names: ");
        name1 = input.nextLine();
        name2 = input.nextLine();
        name3 = input.nextLine();

        String first = "", second = "", third = "";

        
        switch (Character.compare(name1.charAt(0), name2.charAt(0))) {
            case -1:
                switch (Character.compare(name1.charAt(0), name3.charAt(0))) {
                    case -1:
                        first = name1;
                        switch (Character.compare(name2.charAt(0), name3.charAt(0))) {
                            case -1:
                                second = name2;
                                third = name3;
                                break;
                            case 1:
                                second = name3;
                                third = name2;
                                break;
                        }
                        break;
                    case 1:
                        first = name3;
                        second = name1;
                        third = name2;
                        break;
                }
                break;
            case 1:
                switch (Character.compare(name2.charAt(0), name3.charAt(0))) {
                    case -1:
                        first = name2;
                        switch (Character.compare(name1.charAt(0), name3.charAt(0))) {
                            case -1:
                                second = name1;
                                third = name3;
                                break;
                            case 1:
                                second = name3;
                                third = name1;
                                break;
                        }
                        break;
                    case 1:
                        first = name3;
                        second = name2;
                        third = name1;
                        break;
                }
                break;
        }

        System.out.println("Names in alphabetical order:");
        System.out.println(first);
        System.out.println(second);
        System.out.println(third);  
}
}