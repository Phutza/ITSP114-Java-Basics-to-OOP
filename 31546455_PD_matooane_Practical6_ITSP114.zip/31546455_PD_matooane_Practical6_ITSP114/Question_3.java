
/**
 * Write a description of class Q3 here.
 *
 * @author (31546455)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class Question_3
{
    public static void main(String[]args)
    {
        Scanner input = new Scanner(System.in);
        String name;
        int hours_worked;
        char code; 
        
        System.out.print("Pleasenter your name: ");
        name = input.nextLine();
        System.out.print("Please enter hours worked: ");
        hours_worked = input.nextInt();
        System.out.print("Please enter your code(M= Manager & W=Worker): ");
        code = input.next().charAt(0);
        
        double salary = 0;
        switch(code)
        {
            case 'M':
                salary = 50.00 * hours_worked;
                break;
            case 'W':
                salary = 30.00 * hours_worked;
                break;
            default:
                System.out.print("Error. Try again.");
        }
        System.out.print("Please accept your payslip.\n");
        System.out.print(name + ", you worked a total of " + hours_worked + " hours, with the code " + code +".");
        System.out.print("\n\nYour total salary amount is R"+ salary);
    }
}
