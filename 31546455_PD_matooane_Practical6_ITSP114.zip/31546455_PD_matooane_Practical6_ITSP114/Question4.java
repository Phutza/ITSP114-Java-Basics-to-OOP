/**
 * Write a description of class Q4 here.
 *
 * @author (31546455)
 * @version (a version number or a date)
 */
import java.util.Scanner;
import java.lang.Math;
public class Question4
{
    
    public static void main(String[]args)
    {
        Scanner input = new Scanner(System.in);
        String name;
        int mark1;
        int mark2;
        int mark3;
        System.out.print(" Please enter your name: ");
        name = input.nextLine();
        System.out.print("Please enter the three marks: ");
        mark1 = input.nextInt();
        mark2=input.nextInt();
        mark3 = input.nextInt();
        
        int highest_mark = 0;
        switch (Math.max(Math.max(mark1, mark2), mark3)) 
        {
            case 1:
             highest_mark= mark1;
                break;
            case 2:
             highest_mark = mark2;
                break;
            case 3:
             highest_mark = mark3;
                break;
        }
        
        System.out.println(name + "Mark1: " + mark1 + "\nMark2: "+mark2 + "\nMark3: " + mark3);
        System.out.println("Your highest mark is: " + highest_mark);
    }
    
}

