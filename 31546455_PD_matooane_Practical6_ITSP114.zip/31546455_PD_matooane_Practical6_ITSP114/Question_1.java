
/**
 * Determines whether a number is positive or negative.
 *
 * @(31546455)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class Question_1
{
    
    {
        
        
        Scanner sc = new Scanner(System.in);

        System.out.print("Please enter a number");
        String number = sc.nextLine();
        switch(number.charAt(0))
        {
            case '-':
                System.out.println(number + " Negative");
                break;
            
            default:
                System.out.println(number + " Positive");
                break;
        }
    }
}
