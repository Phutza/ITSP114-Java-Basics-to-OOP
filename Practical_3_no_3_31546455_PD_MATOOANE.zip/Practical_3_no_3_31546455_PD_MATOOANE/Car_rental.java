import java.util.*;

/**
 * Write a description of class Car_rental here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Car_rental
{
          public static void main(String[]args)
    {
            
        
               Scanner car = new Scanner (System.in);
          
          System.out.println("Name of a client");
             String name = car.next();
          System.out.println("Car cost");
            double CarCost = car.nextInt();
          System.out.println("Number of days car will be rented");
            int DaysRenting = car.nextInt();
          
            
          double TotalPrice =  CarCost * DaysRenting;
          double Vat = TotalPrice * 0.15;
          double TotalWithVat = TotalPrice + Vat;
          
          System.out.println("Name of a client");
          System.out.println("Car cost");
          System.out.println("Days renting");
          System.out.println("Total price");
          System.out.println("15/100");
          System.out.println("Total Vat");
           
          
          
            
    
             
        
             
             
        
          
          
    }
    
    
    
}
