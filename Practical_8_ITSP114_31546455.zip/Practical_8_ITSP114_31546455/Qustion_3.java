import java.util.Scanner;

/**
 * Write a description of class Qustion_3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Qustion_3
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the times table you would like to practice: ");
        int timesTable = scanner.nextInt();

        int score = 0;
        final int NUM_QUESTIONS = 10;

        System.out.println("Let's practice the " + timesTable + " times table!");

        for (int i = 1; i <= NUM_QUESTIONS; i++) {
            int expectedAnswer = timesTable * i;

            System.out.print(i + ". " + timesTable + " x " + i + " = ? ");
            int userAnswer = scanner.nextInt();

            if (userAnswer == expectedAnswer) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Incorrect, the answer is " + expectedAnswer + ".");
            }
        }

        System.out.println("Your score was " + score + "/" + NUM_QUESTIONS + ".");
        scanner.close();
    }
}