import java.util.Scanner;

/**
 * Write a description of class Question_2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Question_2
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String name;
        String surname;
        int mark;

        System.out.println("Enter student data (Enter 'zzz' for name to exit):");

        while (true) {
            System.out.print("Name: ");
            name = scanner.nextLine();

            if (name.equalsIgnoreCase("zzz")) {
                break;
            }

            System.out.print("Surname: ");
            surname = scanner.nextLine();

            System.out.print("Mark: ");
            mark = scanner.nextInt();
            scanner.nextLine(); 

            
            System.out.println("Student Name: " + name);
            System.out.println("Surname: " + surname);
            System.out.println("Mark: " + mark);
            System.out.println();
        }

        System.out.println("Exiting the program...");
        scanner.close();
    }
}