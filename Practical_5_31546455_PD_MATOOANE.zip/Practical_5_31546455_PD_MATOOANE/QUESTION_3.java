
/**
 * Write a description of class QUESTION_3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;

public class QUESTION_3
{
    
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the worker's name:");
        String name = input.nextLine();

        System.out.println("Enter the worker's code (M for Manager, W for Worker):");
        String code = input.nextLine();

        System.out.println("Enter the hours worked by the worker:");
        double hoursWorked = input.nextDouble();

        double hourlyRate = 0.0;

        if (code.equals("M")) {
            hourlyRate = 50.0;
        } else if (code.equals("W")) {
            hourlyRate = 30.0;
        } else {
            System.out.println("Invalid code entered. Please try again.");
            System.exit(0);
        }

        double salary = hourlyRate * hoursWorked;

        System.out.println("Salary Slip");
        System.out.println("Name: " + name);
        System.out.println("Code: " + code);
        System.out.println("Hours Worked: " + hoursWorked);
        System.out.println("hourlyRate:"+hourlyRate);
        
}
 }
    
       
