
/**
 * Write a description of class QUESTION_1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class QUESTION_1
{
    public static void main(String[]args)
    {
        Scanner in =new Scanner(System.in);
        System.out.println("Enter number:" );
        int input = in.nextInt();
        
        if  (input>0)
        
        System.out.println("Positive");
        
        else if (input<0)
        
          System.out.println("Negative");
        
         else
            System.out.println(input + " is 0.");
    
        
        
    }
}
