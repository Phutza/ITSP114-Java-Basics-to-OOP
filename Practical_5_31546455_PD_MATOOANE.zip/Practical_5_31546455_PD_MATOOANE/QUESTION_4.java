
/**
 * Write a description of class QUESTION_4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class QUESTION_4
{
     public static void main(String[] args)
     {
         Scanner sc = new Scanner(System.in);

        // Ask user to input person's name
        System.out.print("Enter person's name: ");
        String name = sc.nextLine();

        // Ask user to input three marks
        System.out.print("Enter mark 1: ");
        double mark1 = sc.nextDouble();
        System.out.print("Enter mark 2: ");
        double mark2 = sc.nextDouble();
        System.out.print("Enter mark 3: ");
        double mark3 = sc.nextDouble();


        System.out.println("Name: " + name);
        System.out.println("Mark 1: " + mark1);
        System.out.println("Mark 2: " + mark2);
        System.out.println("Mark 3: " + mark3);

        
        double highestMark = Math.max(Math.max(mark1, mark2), mark3);
        System.out.println("Highest mark: " + highestMark);
     }
}
