
/**
 * Write a description of class QUESTION_5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Arrays;
import java.util.Scanner;
public class QUESTION_5
{
      public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter three names (not in alphabetical order):");
        String[] names = new String[3];

        for (int i = 0; i < 3; i++) {
            names[i] = sc.nextLine();
        }

        Arrays.sort(names);

        System.out.println("Names in alphabetical order:");
        for (String name : names) {
            System.out.println(name);
        }
    }
}
       
        
        
    
   

    
          
    
