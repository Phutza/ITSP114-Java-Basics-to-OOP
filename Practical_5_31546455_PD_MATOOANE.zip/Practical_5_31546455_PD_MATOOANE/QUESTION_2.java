
/**
 * Write a description of class QUESTION_2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class QUESTION_2
{
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter client name: ");
        String name = input.nextLine();

        System.out.print("Enter client balance: ");
        double balance = input.nextDouble();

        if (balance < 0) {
            System.out.println(name + " has a negative balance " + balance + ".");
        } else {
            System.out.println(name + "'s balance is " + balance);
        }
   }
}
   