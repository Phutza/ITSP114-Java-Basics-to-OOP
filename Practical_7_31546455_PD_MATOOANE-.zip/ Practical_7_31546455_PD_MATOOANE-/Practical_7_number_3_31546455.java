import java.util.Scanner;

/**
 * Write a description of class Practical_7_no_2_31546455 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Practical_7_number_3_31546455
 {
     public static void main(String[]args)
     {
          Scanner input = new Scanner(System.in);
    int num1, num2, sum;
    char choice;

    do {
        System.out.print("Please enter first number: ");
        num1 = input.nextInt();

        System.out.print("Please enter second number: ");
        num2 = input.nextInt();

        sum = num1 + num2;
        System.out.println("The sum is: " + sum);

        System.out.print("Do you want to continue (yes/no)? ");
        choice = input.next().charAt(0);

        switch (choice) {
            case 'y':
            case 'Y':
                break;
            case 'n':
            case 'N':
                System.out.println("Exiting..");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid choice. Exiting...");
                System.exit(0);
                break;
        }
    } while (choice == 'y' || choice == 'Y');
     }
 }