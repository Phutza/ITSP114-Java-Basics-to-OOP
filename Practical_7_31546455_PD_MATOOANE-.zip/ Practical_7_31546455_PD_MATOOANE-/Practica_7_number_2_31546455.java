import java.util.Scanner;

/**
 * Write a description of class Practica_7_no_3_31546455 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Practica_7_number_2_31546455
{
    public static void main(String[]args)
    {
           Scanner input = new Scanner(System.in);

    System.out.print("Please enter integers: ");
    int number = input.nextInt();

    int reversed = 0;
    while (number != 0) {
        int digit = number % 10;
        switch (digit) {
            case 0:
                reversed = reversed * 10 + 0;
                break;
            case 1:
                reversed = reversed * 10 + 1;
                break;
            case 2:
                reversed = reversed * 10 + 2;
                break;
            case 3:
                reversed = reversed * 10 + 3;
                break;
            case 4:
                reversed = reversed * 10 + 4;
                break;
            case 5:
                reversed = reversed * 10 + 5;
                break;
            case 6:
                reversed = reversed * 10 + 6;
                break;
            case 7:
                reversed = reversed * 10 + 7;
                break;
            case 8:
                reversed = reversed * 10 + 8;
                break;
            case 9:
                reversed = reversed * 10 + 9;
                break;
            default:
                break;
        }
        number /= 10;
    }

    System.out.println("Numbers with reversed digits: " + reversed);
    }
}