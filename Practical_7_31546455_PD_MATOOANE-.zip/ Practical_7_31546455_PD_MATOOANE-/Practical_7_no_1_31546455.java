
/**
 * Write a description of class Practical_7_no_1_31546455 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Practical_7_no_1_31546455
{
 public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            switch (i) {
                case 1:
                    System.out.println("1");
                    break;
                case 2:
                    System.out.println("2");
                    break;
                case 3:
                    System.out.println("3");
                    break;
                case 4:
                    System.out.println("4");
                    break;
                case 5:
                    System.out.println("5");
                    break;
                case 6:
                    System.out.println("6");
                    break;
                case 7:
                    System.out.println("7");
                    break;
                case 8:
                    System.out.println("8");
                    break;
                case 9:
                    System.out.println("9");
                    break;
                case 10:
                    System.out.println("10");
                    break;
                default:
                    System.out.println("Invalid number!");
                    break;
            }
        }
    }
}
