
/**
 * Write a description of class Quetion_5 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Quetion_5
{
   public static void main(String[]args)
   {
       System.out.println("Hello student"+ "                                    "+"ITSP114"+"\nStudy hard for the semester test"+"               "+"You can  do it!");                                
       
   }
   
}
