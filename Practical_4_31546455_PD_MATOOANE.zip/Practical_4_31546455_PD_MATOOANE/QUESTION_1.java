
/**
 * Write a description of class QUESTION_1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.text.DecimalFormat;
public class QUESTION_1
{
    public static void main(String[]args)
    {
        double change = 2.58;
        int cents1 =(int)(change*100);
        int cents2 =(int)(change*100);
        System.out.println("Change in cents is"+cents1);
        System.out.println("Change in cents is "+cents1);
        
        
        
    }
}
