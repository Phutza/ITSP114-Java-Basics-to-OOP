
/**
 * Write a description of class Question_3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Question_3
{
    public static void main(String[]args)
    {
        String item1 ="25.63";
        String item2 ="52";
        String together = item1 +item2;
        double P4 =Double.parseDouble(item1);
        int P3 =Integer.parseInt(item2);
        double sum=P4+P3;
        System.out.println("The total of the items are"+ " "+sum);

        
    
        

    }
}
