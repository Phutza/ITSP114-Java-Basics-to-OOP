
/**
 * Write a description of class Questtion_2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Question_2
{
    public static void main(String[]args)
    {
        System.out.println("31546455"+ " "+"Phuti Matooane");

    }
}
