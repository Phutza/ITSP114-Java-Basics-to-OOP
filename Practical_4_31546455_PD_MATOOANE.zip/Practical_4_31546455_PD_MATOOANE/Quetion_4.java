
/**
 * Write a description of class Quetion_4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Quetion_4
{
    public static void main (String[]args)
    {
        String name = "Phuti Matooane";
        
        int n =name.length();
        System.out.println("Length of"+name+"is"+n);
        
        String pp=name.toLowerCase();
        System.out.println(pp);
        
        char d=name.charAt(10);
        System.out.println(d);
        
        String van=name.substring(5,11);
        System.out.println(van);
        
        
    
    }

}
