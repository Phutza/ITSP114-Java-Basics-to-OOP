
/**
 * Write a description of class Exercise_2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Exercise_2
{
   public static void main(String[] args)
    {
        System.out.println(" +\"\"\"\"\"+ ");
        System.out.println("[| o o |]");
        System.out.println(" |  ^  | ");
        System.out.println(" | '-' | ");
        System.out.println(" +-----+ ");
    }
}
