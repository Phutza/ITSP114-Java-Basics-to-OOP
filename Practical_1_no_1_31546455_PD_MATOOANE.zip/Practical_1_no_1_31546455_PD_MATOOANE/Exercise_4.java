
/**
 * Write a description of class Exercise_4 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.JOptionPane;

public class Exercise_4{
    public static void main(String[]args){
        JOptionPane.showMessageDialog(null,"For me to pass this module I have to work through the Smart Guide!!!", "Display Message", JOptionPane.WARNING_MESSAGE);
    
    
    }
}
    
    
