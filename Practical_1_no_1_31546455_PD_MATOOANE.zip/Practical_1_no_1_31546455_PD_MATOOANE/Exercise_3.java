
/**
 * Write a description of class Exercise_3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.JOptionPane;

public class Exercise_3{
    public static void main(String[]args){
        JOptionPane.showMessageDialog(null,"Phuti Matooane", "Display Name", JOptionPane.INFORMATION_MESSAGE);
    
    
    }
    
}

