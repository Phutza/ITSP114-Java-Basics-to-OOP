
/**
 * Write a description of class Exercise_1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Exercise_1
{
     public static void main(String[] args)
     {
  System.out.println("Hello\nPhuti Matooane");
} 
}
