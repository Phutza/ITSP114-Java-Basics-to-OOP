
/**
 * Write a description of class exercise_2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.JOptionPane;
public class exercise_2
{
    public static void main(String[]args)
    {
        String student_number=JOptionPane.showInputDialog("Enter student number");
        System.out.println("Student number"+student_number);
        String name_and_surname=JOptionPane.showInputDialog("Enter your name and surname");
        System.out.println("Name and surname"+name_and_surname);
    }
}
