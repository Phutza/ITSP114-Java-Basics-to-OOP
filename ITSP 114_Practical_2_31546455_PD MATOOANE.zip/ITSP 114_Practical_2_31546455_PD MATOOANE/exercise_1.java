
/**
 * Write a description of class exercise_1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

  import java.util.Scanner;
  public class exercise_1
  {
    public static void main(String[]args)
    {
      Scanner input= new Scanner(System.in);
      System.out.print("Enter student number");
      String student_number= input.nextLine();
      System.out.print("Enter name and surname ");
      String name_and_surname= input.nextLine();
      System.out.println("Hello \n"+student_number+" +");
      
    }
    
    
    
  }
    

